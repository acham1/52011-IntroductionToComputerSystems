import java.util.*;
import java.lang.*;
import java.lang.reflect.Array;

public class BallSampler<K> {
    Bucket bucket;

    public BallSampler() {
        this.bucket = new Bucket();
    }

    public K getSample() {
        Ball ball = bucket.getRandomBall();
        return (ball == null) ? null : ball.key;
    }

    public void add(K key, int cardinality) {
        for (int i = 0; i < cardinality; i++) {
            this.bucket.incrementBall(key);
        }
    }

    public K sample() {
        return this.bucket.getRandomBall().key;
    }

    public int getCardinality(K key) {
        if (!this.bucket.containsKey(key)) {
            return 0;
        } else {
            return bucket.getCardinality(key);
        }
    }

    public void increment(K key) {
        this.bucket.incrementBall(key);
    }

    public void decrement(K key) {
        this.bucket.decrementBall(key);
    }

    private class Bucket {
        private static final int DEFAULT_ARRAY_LEN = 1;
        private static final double MAX_OCCUPATION_RATE = 0.5;
        private static final int CAPACITY_GROWTH_FACTOR = 2;

        private int capacity;
        private int occupancy;
        private Ball[] ballArray;
        private LinkedList<K> listElements;
        private Hashtable<K, LinkedList<Integer>> ballIndices;
        private Random rand;

        private Bucket() {
            this(DEFAULT_ARRAY_LEN);
        }

        private Bucket(int numBalls) {
            this.occupancy = 0;
            Double capacityDouble = Math.ceil(numBalls/MAX_OCCUPATION_RATE);
            this.capacity = capacityDouble.intValue();
            @SuppressWarnings("unchecked")
            Ball[] ballArray = (Ball[]) Array.newInstance((new Ball()).getClass(), this.capacity);
            this.ballArray = ballArray;
            this.listElements = new LinkedList<K>();
            this.ballIndices = new Hashtable<K, LinkedList<Integer>>();
            this.rand = new Random(System.currentTimeMillis());
        }

        private boolean containsKey(K key) {
            return this.ballIndices.containsKey(key);
        }

        private int getCardinality(K key) {
            if (!this.containsKey(key)) {
                return 0;
            } else {
                return this.ballIndices.get(key).size();
            }
        }

        private void resize(int newCapacity) {
            this.capacity *= CAPACITY_GROWTH_FACTOR;
            @SuppressWarnings("unchecked")
            Ball[] ballArray = (Ball[]) Array.newInstance((new Ball()).getClass(), this.capacity * CAPACITY_GROWTH_FACTOR);
            this.ballArray = ballArray;
            this.occupancy = 0;
            for (ListIterator<K> iter = this.listElements.listIterator(); iter.hasNext();) {
                K key = iter.next();
                int size = this.ballIndices.get(key).size();
                if (size <= 0) {
                    this.ballIndices.remove(key);
                    iter.remove();
                    continue;
                }
                this.ballIndices.put(key, new LinkedList<Integer>());
                for (int i = 0; i < size; i++) {
                    this.incrementBall(key);
                }
            }
        }

        /**
         * @return true if success, false otherwise
         */
        private boolean incrementBall(K key) {
            Ball ball = new Ball(key, false);
            if ((double) (this.occupancy + 1) / this.capacity >= MAX_OCCUPATION_RATE) {
                this.resize(this.capacity * CAPACITY_GROWTH_FACTOR);
            }
            int code = Math.abs(key.hashCode() % this.capacity);
            for (int i = code; i < this.capacity; i++) {
                if (this.ballArray[i] == null || this.ballArray[i].deleted) {
                    this.ballArray[i] = ball;
                    this.addRecords(key, i);
                    return true;
                }
            }
            for (int i = 0; i < code; i++) {
                if (this.ballArray[i] == null || this.ballArray[i].deleted) {
                    this.ballArray[i] = ball;
                    this.addRecords(key, i);
                    return true;
                }
            }
            return false;
        }

        private void addRecords(K key, int i) {
            if (!this.listElements.contains(key)) {
                this.listElements.add(key);
            }
            if (!this.ballIndices.containsKey(key)) {
                this.ballIndices.put(key, new LinkedList<Integer>());
            }
            this.occupancy++;
            this.ballIndices.get(key).add(i);
        }

        private boolean decrementBall(K key) {
            int code = key.hashCode() % this.capacity;
            for (int i = code; i < this.capacity; i++) {
                if (this.ballArray[i] == null) {
                    return false;
                }
                if (!this.ballArray[i].deleted && this.ballArray[i].key.equals(key)) {
                    this.ballArray[i].deleted = true;
                    this.deleteRecords(key, i);
                    return true;
                }
            }
            for (int i = 0; i < code; i++) {
                if (this.ballArray[i] == null) {
                    return false;
                }
                if (!this.ballArray[i].deleted && this.ballArray[i].key.equals(key)) {
                    this.ballArray[i].deleted = true;
                    this.deleteRecords(key, i);
                    return true;
                }
            }
            return false;
        }

        private void deleteRecords(K key, int i) {
            LinkedList<Integer> indexList = this.ballIndices.get(key);
            if (indexList != null) {
                indexList.remove(new Integer(i));
                if (indexList.size() <= 0) {
                    this.listElements.remove(key);
                    this.ballIndices.remove(key);
                }
            }
        }

        private Ball getRandomBall() {
            int select = rand.nextInt() % this.capacity;
            while (select < 0 || this.ballArray[select] == null || this.ballArray[select].deleted) {
                select = rand.nextInt() % this.capacity;
            }
            return this.ballArray[select];
        }
    }

    private class Ball {
        K key;              // stores a value
        boolean deleted;    // boolean: has the Ball been deleted

        private Ball() {
            this(null, false);
        }

        private Ball(K key, boolean deleted) {
            this.key = key;
            this.deleted = deleted;
        }
    }
}