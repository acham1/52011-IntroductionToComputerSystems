import java.io.*;
import java.util.*;

public class AdaptiveFlashCards {

    private enum SessionType {
        LOAD_NEW_FILE,
        LOAD_OLD_SESSION,
        OTHER
    } // end enum SessionType

    public static void main(String[] args) {
        boolean save = false;
        boolean exit = false;
        Options options = new Options(args);
        if (!options.isValid()) {
            options.printManual();
            System.exit(1);
        }
        LinkedList<Pair> pairList = new LinkedList<Pair>();
        if (options.type == SessionType.LOAD_NEW_FILE) {
            pairList = readNewFile(options.argFile);
        } else if (options.type == SessionType.LOAD_OLD_SESSION) {
            pairList = readOldSession(options.argFile);
        }
        BallSampler<String> sampler = new BallSampler<String>();
        Hashtable<String, String> answers = new Hashtable<String, String>();
        for (Pair pair : pairList) {
            answers.put(pair.key, pair.value);
            sampler.add(pair.key, pair.cardinality);
        }
        try (
                Scanner scan = new Scanner(System.in);
        ) {
            System.out.println("Usage instructions:");
            System.out.println("1. Flash Cards reveal keyword.");
            System.out.println("2. Try to recall the definition.");
            System.out.println("3. Press Enter when ready to see answer.");
            System.out.println("4. Enter y(yes) you were correct\n"
                    + "\tn(no) if you were wrong\n"
                    + "\ts(n/a) if question is not applicable\n"
                    + "\tx(exit) to quit\n");
            while (!exit) {
                System.out.println("-----------------------------------------\n");
                String sample = sampler.sample();
                System.out.println("Key: " + sample);
                while (!scan.nextLine().isEmpty()) {
                    System.out.println("Press Enter when ready to see answer.");
                }
                System.out.println("Answer: " + answers.get(sample));
                System.out.print("Correct (y/n/s/x)? ");
                boolean setCorrectness = false;
                while (!setCorrectness) {
                    String reply = scan.nextLine();
                    if (reply.equals("y")) {
                        if (sampler.getCardinality(sample) > 1) {
                            System.out.println("Decrementing probability of " + sample + "(" + sampler.getCardinality(sample) + ")");
                            sampler.decrement(sample);
                        } else {
                            System.out.println("Did not decrement probability of " + sample);
                        }
                        setCorrectness = true;
                    } else if (reply.equals("n")){
                        sampler.increment(sample);
                        setCorrectness = true;
                    } else if (reply.equals("s")) {
                        setCorrectness = true;
                    } else if (reply.equals("x")) {
                        exit = true;
                        setCorrectness = true;
                    }
                }
            }
            System.out.println("Save progress (will overwrite)? y(yes), n(no)");
            boolean setSave = false;
            while (!setSave) {
                String reply = scan.nextLine();
                if (reply.equals("y")) {
                    save = true;
                    break;
                } else if (reply.equals("n")){
                    save = false;
                    break;
                }
            }
        } catch (NoSuchElementException nsee) {
            System.err.println("Error: no more user input; ending program.");
            System.exit(1);
        }
        if (save) {
            printSamplerState(sampler, options, pairList);
        }
    } // end method AdaptiveFlashCards.main(Srtring[] args)

    private static void printSamplerState(BallSampler<String> sampler, Options options, LinkedList<Pair> pairList) {
        String name;
        if (options.argFile.getName().endsWith(".old")) {
            name = options.argFile.getName();
        } else {
            name = options.argFile.getName() + ".old";
        }
        File outFile = new File(name);
        try (
                PrintWriter pw = new PrintWriter(outFile);
        ) {
            for (Pair pair : pairList) {
                pw.printf("%s %s %s\n", sampler.getCardinality(pair.key), pair.key, pair.value);
            }
        } catch (FileNotFoundException fnfe) {
            System.err.println("Error: could not write output file " + outFile.getName());
        }
    }

    private static LinkedList<Pair> readNewFile(File file) {
        LinkedList<Pair> pairList = new LinkedList<Pair>();
        try (
                FileReader reader = new FileReader(file);
                BufferedReader br = new BufferedReader(reader);
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] terms = line.split("[\\s]+");
                    if (terms.length < 2) {
                        System.err.println("Warning: did not find value for key " + terms[0]);
                        continue;
                    }
                    String key = terms[0];
                    String value = line.substring(key.length()).trim();
                    Pair newPair = new Pair(key, value, 1);
                    pairList.add(newPair);
                }
            }
        } catch (IOException ioe) {
            System.out.println("Error: IOException when reading input file.");
            System.exit(1);
        }
        return pairList;
    }

    private static LinkedList<Pair> readOldSession(File file) {
        LinkedList<Pair> pairList = new LinkedList<Pair>();
        try (
                FileReader reader = new FileReader(file);
                BufferedReader br = new BufferedReader(reader);
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] terms = line.split("[\\s]+");
                    if (terms.length < 3) {
                        System.err.println("Warning: invalid line " + line);
                        continue;
                    }
                    int cardinality = Integer.parseInt(terms[0]);
                    line = line.substring(terms[0].length()).trim();
                    terms = line.split("[\\s]+");
                    String key = terms[0];
                    String value = line.substring(key.length()).trim();
                    Pair newPair = new Pair(key, value, cardinality);
                    pairList.add(newPair);
                }
            }
        } catch (IOException ioe) {
            System.out.println("Error: IOException when reading input file.");
            System.exit(1);
        }
        return pairList;
    }


    private static class Options {
        private static final String[] knownFlags = {"-n", "-o"};

        private SessionType type = SessionType.OTHER;
        private File argFile = null;

        private Options(String[] args) {
            for (int i = 0; i < args.length; i++) {
                for (String flag : Options.knownFlags) {
                    if (flag.equals(args[i])) {
                        this.type = parseArg(Arrays.copyOfRange(args, i, args.length));
                        return;
                    }
                }
                System.err.println("Error: unrecognized argument " + args[i]);
                return;
            }
        } // end method AdaptiveFlashCards.Options.Options(String[] args)

        private SessionType parseArg(String[] args) {
            if (args.length < 2) {
                System.out.println("Error: expecting file name argument for option " + args[0]);
                return SessionType.OTHER;
            }
            File file = new File(args[1]);
            if (file.exists()) {
                this.argFile = file;
                return args[0].equals("-n") ? SessionType.LOAD_NEW_FILE : SessionType.LOAD_OLD_SESSION;
            } else {
                System.out.println("Error: did not find file " + args[1]);
                return SessionType.OTHER;
            }
        }

        private boolean isValid() {
            return this.type != SessionType.OTHER;
        }

        private void printManual() {
            System.out.println("Usage: run the program with one of the following options:");
            System.out.println("\tjava AdaptiveFlashCards -n <new file to load>");
            System.out.println("\tjava AdaptiveFlashCards -o <old session records to load>");
        }
    } // end class AdaptiveFlashCards.Options

    private static class Pair {
        public String key = null;
        public String value = null;
        public int cardinality = 0;

        private Pair(String key, String value, int cardinality) {
            this.key = key;
            this.value = value;
            this.cardinality = cardinality;
        }
    }
} // end class AdaptiveFlashCards