Alan Cham
Introduction to Computer Systems
Project 1: Logic Gates
README.txt

All assigned chips have been submitted in working state.
Building the parallel chips (e.g. Not16, Or16, etc) is relatively
simple, but extending simple chips into multi-way is also ok
once the pattern is recognized. Most challenging aspect is in
trying to minimize the number of chip parts used.