/**
 *  Alan Cham
 *  52011 - Introduction to Computer Systems
 *  Project 09
 *  February 16, 2016
 *  README.txt
 */
-----------------
Game Instructions
-----------------

The objective of the game is to minimize the number of screen registers
that have been colored.

 - Once the game is loaded, it will wait at the title screen.
To start the game, press any arrow key.

 - A black square will begin moving "randomly" on the screen, coloring in
a trail of black pixels.

 - Meet the objective by using the arrow keys to drive a white square which
erases black pixels that it travels over.

- The game ends when the timer runs out. A score will be displayed on the
top left.

