Alan Cham
Introduction to Computer Systems
Project 5: Computer Architecture
README.txt

All assigned components have been submitted in working order.
I initially had a problem building the computer because I forgot
a Memory chip exists, and I tried using RAM16K directly, which
failed. But once I used the memory chip, everything was fine.